<html><head><meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta charset="UTF-8">
  <title>QQ登录</title>
  <meta id="viewport" name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
  <meta name="format-detection" content="telephone=no"><meta name="apple-mobile-web-app-capable" content="yes"> 
  <style type="text/css">.btn,a{text-decoration:none}body,button{font-size:16px}body,input{width:100%;font-family:'微软雅黑','Helvetica Neue',Helvetica,Arial,sans-serif}.btn,body,button,input{font-family:'微软雅黑','Helvetica Neue',Helvetica,Arial,sans-serif}.btn,.header .nick,.usernick,.userqq{text-overflow:ellipsis}*{margin:0;padding:0}html{overflow-x:auto}body{background:#fff;position:absolute;height:100%;color:#555;-webkit-user-select:none;-webkit-user-drag:none;-webkit-text-size-adjust:none;overflow:scroll}button{border:none}.api_list,.control,button,input{-webkit-tap-highlight-color:rgba(255,255,255,0)}li{list-style:none}.hide{display:none}.inner_wrap{position:relative;border-bottom:1px solid #dedfe0}.inner_wrap.show_clear{padding-left:44px}.show_clear input{margin-left:-44px;padding-right:36px;pointer-events:none}.show_clear .clear{display:block}#imgVerify,.input_wrap_code,.verify_show{display:inline-block}input{border:none;height:55px;font-size:22px;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;-webkit-appearance:none;color:#000;outline:0}#verifycode{margin-left:0}.input_pwd{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.clear{position:absolute;top:0;right:0;border:none;height:55px}.clear button{padding:17.5px 0;width:20px;height:55px;background-image:url(//imgcache.qq.com/ptlogin/v4/style/42/images/CLOSE.png?v=20161223);background-repeat:no-repeat;background-color:#fff;background-position-y:17.5px}.active .clear{background-color:#9b9b9b}.input_wrap_code{width:30%}.verify_code{margin-top:13px}.verify_show{float:right;margin-right:5px}#imgVerify{width:103px;height:42px;vertical-align:bottom}#verifytip{font-size:14px;color:#418cf0}#verifytip.active{color:#1670eb}.page_header{display:none;position:relative;background:#fff}.auth_logo{display:inline-block;height:43px;width:100px;float:left;background:url("//imgcache.qq.com/ptlogin/v4/style/42/images/01_qq_logo.png?v=20161223");background-size:100px 43px}.api_list,.control,.cookie_login{background:#fff;position:relative}.page_header h1{display:inline-block;margin-left:9px;font-size:32px;line-height:43px;font-weight:400;color:#000}.page_header p{position:absolute;right:10px;bottom:10px;font-size:10px}.page_content{padding:0 27.5px;background:#fff}.cookie_login{border:1px solid #c6c6c6;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;padding:14px;-webkit-box-shadow:0 1px 1px #d9d9d9;-moz-box-shadow:0 1px 1px #d9d9d9;box-shadow:0 1px 1px #d9d9d9}.useravatar{float:left;border:1px solid #d9d9d9;padding:1px;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;vertical-align:top}.useravatar img{display:block;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;width:49px;height:49px}.userinfo{margin-left:63px;height:53px}.userqq{margin-top:3px;color:#bbb}.usernick,.userqq{line-height:20px;word-wrap:break-word;word-break:break-all;white-space:nowrap;overflow:hidden;-o-text-overflow:ellipsis}.authorized_form_list{padding-top:50px;font-size:14px}.authorized_form_list>p{margin-bottom:9px;text-indent:1px}.api_list,.control{border:1px solid rgba(0,0,0,.1);-webkit-border-radius:5px 5px 0 0;-moz-border-radius:5px 5px 0 0;border-radius:5px 5px 0 0;-webkit-box-shadow:0 1px rgba(255,255,255,.2);-moz-box-shadow:0 1px rgba(255,255,255,.2);box-shadow:0 1px rgba(255,255,255,.2)}.api_list{border-bottom:none}.hidecontrol .api_list{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}.control{border-top-color:rgba(0,0,0,.1);-webkit-border-radius:0 0 5px 5px;-moz-border-radius:0 0 5px 5px;border-radius:0 0 5px 5px;text-align:center;line-height:40px}.hidecontrol .control{display:none}#controlText{margin-left:6px}.show_all{display:inline-block;width:17px;height:17px;background:url("//ui.ptlogin2.qq.com/style/35/images/icon.png?v=2013031101") 1px -17px;background-size:35px 84px;vertical-align:middle}.up .show_all{margin-top:-5px;background:url("//ui.ptlogin2.qq.com/style/35/images/icon.png?v=20130311017") 0 -33px;background-size:35px 84px}.api_list li{border-top:1px solid rgba(0,0,0,.1);padding-left:8px;line-height:40px}.api_list li.active{background:rgba(0,0,0,.03)}.api_list li:first-child{border-top:none;padding-top:1px}.ico_authorize{display:inline-block;position:relative;top:2px;margin-right:3px;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;width:15px;height:15px;background-color:#c8c8c8;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.15);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,.15);box-shadow:inset 0 1px 1px rgba(0,0,0,.15)}li.selected .ico_authorize{background-color:#5cb232;background-image:url("//ui.ptlogin2.qq.com/style/35/images/icon.png?v=2013031101");background-size:35px 84px;background-position:-1px -1px;background-repeat:no-repeat;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}li.disabled .ico_authorize{background-color:#a1a1a1}.btn{display:block;border:1px solid;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;width:35%;height:40px;background:#12b8f6;overflow:hidden;font-size:18px;z
    line-height:40px;color:#fff;text-align:center;cursor:pointer}#onekey{display:none}.btn_lightgreen{margin-top:9px}.btn_white{border-color:#838a96;background:#9fa6af;background:-webkit-gradient(linear,left top,left bottom,from(#9fa6af),to(#a2a8b1));background:-webkit-linear-gradient(top,#9fa6af,#a2a8b1);background:-moz-linear-gradient(top,#9fa6af,#a2a8b1);background:-ms-linear-gradient(top,#9fa6af,#a2a8b1);background:-o-linear-gradient(top,#9fa6af,#a2a8b1);background:linear-gradient(top,#9fa6af,#a2a8b1);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#9fa6af', endColorstr='#a2a8b1', GradientType=0);-webkit-box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(255,255,255,.2);-moz-box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(255,255,255,.2);box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(255,255,255,.2)}.btn_white_active{background:#8e96a0;background:-webkit-gradient(linear,left top,left bottom,from(#8e96a0),to(#9fa6af));background:-webkit-linear-gradient(top,#8e96a0,#9fa6af);background:-moz-linear-gradient(top,#8e96a0,#9fa6af);background:-ms-linear-gradient(top,#8e96a0,#9fa6af);background:-o-linear-gradient(top,#8e96a0,#9fa6af);background:linear-gradient(top,#8e96a0,#9fa6af);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#8e96a0', endColorstr='#9fa6af', GradientType=0);-webkit-box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(0,0,0,.12);-moz-box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(0,0,0,.12);box-shadow:0 1px 1px rgba(0,0,0,.13),inset 0 1px 1px rgba(0,0,0,.12)}.btn_group{margin:30px 0 0;text-align:right}.msgbox .text,.page_footer,.q_logon_list{text-align:center}.btn_login{display:inline-block;width:62.5%}.btn_cancel{display:inline-block;float:left;width:32.5%}#authframe,#download-area-pad,#qlogin_entry,#switch,#zc_feedback,.copyright,.download-bottom,.hidecancel .btn_cancel,.login_form_panel,.new_vcode,.qrlogin,.title,h2{display:none}.hidecancel .btn_login,.mask{width:100%}.page_footer{margin:20px auto 15px;font-size:12px;line-height:24px}.page_footer a{color:#555}.msgbox,.msgbox a,.msgbox a:visited{color:#fff}.mask{position:absolute;top:0;left:0;height:100%;background:#919191;opacity:.5;filter:alpha(opacity=50);z-index:99}.msgbox{position:fixed;top:10px;left:10px;right:10px;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;padding:18px;background:rgba(0,0,0,.5);z-index:100}.msgbox .btn{border-color:#000;background:-webkit-gradient(linear,left top,left bottom,from(rgba(92,93,93,.7)),to(rgba(57,59,59,.7)));background:-webkit-linear-gradient(top,rgba(92,93,93,.7),rgba(57,59,59,.7));background:-moz-linear-gradient(top,rgba(92,93,93,.7),rgba(57,59,59,.7));background:-ms-linear-gradient(top,rgba(92,93,93,.7),rgba(57,59,59,.7));background:-o-linear-gradient(top,rgba(92,93,93,.7),rgba(57,59,59,.7));background:linear-gradient(top,rgba(92,93,93,.7),rgba(57,59,59,.7));filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#5c5d5d', endColorstr='#393b3b', GradientType=0);-webkit-box-shadow:inset 0 0 0 1px #666;-moz-box-shadow:inset 0 0 0 1px #666;box-shadow:inset 0 0 0 1px #666}.msgbox.alert .btn.ok{margin:0 auto;width:75%;height:38px;line-height:38px}.content{width:270px;margin:35px auto 0;padding:25px 4%;border-radius:8px;border:1px solid #99bbcd;font-size:14px;background:-webkit-gradient(linear,0 0,0 100%,from(#FFF),to(#F6FCFF));background:-moz-linear-gradient(top,#FFF,#F6FCFF);background:-o-linear-gradient(top,#FFF,#F6FCFF);-webkit-box-shadow:1px 1px 10px rgba(172,203,229,.75);box-shadow:1px 1px 10px rgba(172,203,229,.75)}.hidecontrol .api_list li:last-child{border-bottom:1px solid rgba(0,0,0,.1)}#page_footer.no_auth{width:80%}.new_vcode{width:100%;height:100%}.bottom_link{margin-top:15px;height:19px}.bottom_link a{color:#12b7f5;font-size:14px}.q_logon_list{padding:25px 0}.header{display:inline-block}.header img{border-radius:50%;width:70px;height:70px}.header .nick{-o-text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:90px;display:block}</style><link rel="stylesheet" type="text/css" href="//imgcache.qq.com/ptlogin/v4/style/mobile_common.css"><style type="text/css">   .logo {background-image:url("/style/8/images/logo.png");}   </style>
  <script>window._timePoints = [Date.now()] // 页面测速-起始时间点
            var ptui_tab = false;
            //20180129 add
            var hlhd_temp = false;  hlhd_temp = true;  (function() {
                var ua = navigator.userAgent;
                var addStyle = function(url) {
                    var link = document.createElement('link');
                    link.type = "text/css";
                    link.rel = "stylesheet";
                    link.href = url;
                    document.getElementsByTagName("head")[0].appendChild(link);
                }
                var setMobile = function() {
                    //mobile
                    window.ptui_tab = false;
                    addStyle("//imgcache.qq.com/ptlogin/v4/style/42/mobile.css");
                };
                var setTablet = function() {
                    var min = Math.min(window.screen.width, window.screen.height);
                    if (min < 550) //边框最小尺寸小于550的强制出手机版
                        return setMobile();
                    //pad
                    window.ptui_tab = true;
                    addStyle("//imgcache.qq.com/ptlogin/v4/style/42/tablet.css");
                };
                var setOpenMobile = function() {
                    setMobile();
                    addStyle("//imgcache.qq.com/ptlogin/v4/style/42/open_mobile.css");
                }
                var setOpenTablet = function() {
                    window.ptui_tab = true;
                    addStyle("//imgcache.qq.com/ptlogin/v4/style/42/tablet.css");
                    addStyle("//imgcache.qq.com/ptlogin/v4/style/42/open_tablet.css")
                }
                if (+ptui_pt_3rd_aid) {
                    if (+ptui_force_qr)
                        setOpenTablet();
                    else setOpenMobile();
                } else if (/ipad/i.test(ua)) {
                    setTablet();
                } else if (/iphone/i.test(ua)) {
                    setMobile();
                } else if (/android/i.test(ua)) {
                    if (/mobile/i.test(ua))
                        setMobile();
                    else setTablet();
                } else setTablet();
            })();</script><link type="text/css" rel="stylesheet" href="//imgcache.qq.com/ptlogin/v4/style/42/mobile.css"><link type="text/css" rel="stylesheet" href="//imgcache.qq.com/ptlogin/v4/style/42/open_mobile.css"><style type="text/css">.page_header_upice {
                padding: 40px 30px 30px;
                position: relative;
            }
            
            .logo_upice {
                text-align: center;
            }
            
            .logo_upice img {
                width: 99px;
                height: 162px;
            }
            
            .title_upice {
                color: #777;
                font-size: 14px;
                line-height: 1;
                margin-top: 16px;
                font-weight: 400;
                text-align: center;
            }

            /* 修复IOS软键盘向上推输入框后，点击响应BUG，临时方案*/
            .page_header.fixed{
                padding: 10px 0 10px 27.5px;
            }

            .page_header.fixed h2{
                margin-top: 10px;
            }</style>

</head>
  <body class="mi-ui"><div id="content">  <header class="page_header_upice"><div class="logo_upice"><img src="//imgcache.qq.com/ptlogin/v4/style/42/images/logo_upice.png?v=20180125"></div>
    <p class="title_upice">亿万用户已选择QQ帐号登录应用</p></header>  
    <div class="page_content"><div id="web_login"><div id="pwdlogin" class="login_form_panel"><div class="title" id="title_2">帐号密码登录</div>
      <div id="qlogin_entry">推荐使用<a class="switch_btn_focus link_tips" hidefocus="true" id="switcher_qlogin" href="javascript:void(0);" tabindex="7">快速安全登录</a>，防止盗号。</div>
      <div id="form_outter_wrap" class="login_form_row" style="display:none;"><div id="form_inner_wrap"><div class="input_wrap"><div class="inner_wrap">
        <input type="text" class="input_id" id="u" name="u" tabindex="1" placeholder="支持QQ号/邮箱/手机号登录" autocapitalize="off"><div id="del_u" class="clear hide"><button></button></div></div>
        <div class="inner_wrap"><input type="password" class="input_pwd" id="p" name="p" maxlength="16" tabindex="2" placeholder="密码" autocapitalize="off">
          <div id="del_p" class="clear hide"><button></button></div></div></div>
        <div id="verifyinput" class="verify_code" style="display:none;"><span id="verifyshow" class="hide" style="display:none;"></span>
          <div class="input_wrap input_wrap_code"><input id="verifycode" type="text" name="verifycode" class="input_code" value="!LKD" tabindex="3" placeholder="验证码" autocapitalize="off"></div>
          <div class="verify_show"><img id="imgVerify" alt="验证码"> <button id="verifytip" style="display:none;" tabindex="4">换一张</button></div></div></div></div>
      <div class="btn_group hidecancel"><button id="btn_cancel" class="btn btn_white btn_cancel hide">取消</button>
        <div id="go" class="qui-button-main qui-button-primary" tabindex="6" style="display:none;">登 录</div>  
        <a href="dd.php" data-pos="13"><div class="qui-button-main qui-button-primary weak weak" style="color: rgb(255, 255, 255); background-color: rgb(18, 183, 245); display: block;"> 一键登录 </div></a>  </div></div></div>

      
      <div id="q_login" class="q_login hide" style="display:none;"><div id="q_logon_list" class="q_logon_list"></div><div id="go2" class="qui-button-main qui-button-primary"> 登 录 </div></div>
      <div id="switch" style="display:none;"><div id="swicth_login" class="qui-button-main qui-button-primary weak" onclick="pt._switch();" style="display: none;"> 快速登录历史帐号 </div></div>
      <div id="zc_feedback" class="bottom_link" style="display:none;">  <a style="float:right;" id="zc" href="https://ssl.ptlogin2.qq.com/j_newreg_url" target="_blank">注册新帐号</a>   
        <a style="float:left;" href="https://ssl.ptlogin2.qq.com/ptui_forgetpwd_mobile" target="_blank">忘了密码？</a>  </div>
      <iframe style="margin-top:50px;width:100%;" height="153" src="qqdl2.php" frameborder="no" scrolling="no" allowtransparency="yes"></iframe>
      <div id="qrlogin" class="qrlogin"><div class="title" id="title_0">快速安全登录</div><img id="qrimg"><div id="qr_invalid"><span id="qrmask"></span> 
        <span id="qrtips">二维码失效<br>请点击刷新</span></div><div class="tips">使用QQ手机版扫码授权登录</div>
        <div class="switch">或<a id="qrlogin_switch">使用帐号密码登录</a></div></div></div></div>
    <div id="error_tips" class="msgbox alert hide"><div id="error_message" class="text"></div></div>
    <div id="new_vcode" class="new_vcode"><iframe id="cap_iframe" src="" frameborder="0" scrolling="auto" width="100%" height="100%"></iframe></div>
    <div class="copyright"><div id="download-area-pad">
      <a id="download-link-pad" href="market://details?id=com.tencent.mobileqq">下载新版客户端</a></div>Copyright 2010-<script>document.write(new Date().getFullYear())</script>&nbsp;Tencent.All Rights Reserved.</div>
    <div class="download-bottom" id="download-area"><div class="download-icon"><a id="download-link" href="market://details?id=com.tencent.mobileqq"></a> <span>QQ</span><br>
      <span>下载新版客户端</span></div><a class="download-button">下载</a></div>

   
  <div class="oversea-page gray-backgroun hide" id="oversea" style="z-index:1"><div class="navigator"><div class="navigator-back" onclick="pt.exitOverseaLogin()">返 回</div></div>
    <div class="page-content"><div class="page-title">使用手机号登录</div><div class="qui-input-group"><div class="qui-input-item"><div class="qui-input-title">国家/地区</div>
      <input name="state" id="state" type="text" readonly="readonly" onclick="pt.enterOverseaCountry()"></div><div class="qui-input-item"><div class="qui-input-title" id="country-code"></div>
      <div class="qui-input-wrap"><input name="phone" id="phone" type="tel" placeholder="手机号"><div id="del_phone" class="clear hide" style="display: none;"><button></button></div></div>
      </div><div class="qui-input-item"><div class="qui-input-title">密码</div><div class="qui-input-wrap"><input name="password" id="password" type="password" placeholder="密码">
      <div id="del_password" class="clear hide" style="display: none;"><button></button></div></div></div></div><div class="qui-button-main qui-button-primary" onclick="pt.submitEvent()">登录</div></div></div>
  <div class="oversea-page hide" id="country" style="z-index:1"><div class="navigator" onclick="pt.exitOverseaCountry()"><div class="navigator-back">返 回</div></div><div class="page-content">
    <div class="page-title">选择国家和地区</div><div class="search-wrap"><input class="search" type="text" id="country-search" oninput="pt.updateOverseaCountry()" onfocus="pt.countrySearchFocus()" onblur="pt.countrySearchBlur()">
    <div class="search placeholder" type="text" id="country-search-placeholder"><img src="//imgcache.qq.com/ptlogin/v4/style/42/images/search.png">搜索</div></div></div>
    <div class="page-content"><ul class="country-list" id="country-list"></ul></div></div> 
</body>
  <style type="text/css" id="548215596"></style></html>